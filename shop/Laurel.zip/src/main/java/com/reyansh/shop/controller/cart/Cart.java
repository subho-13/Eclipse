package com.reyansh.shop.controller.cart;

import com.reyansh.shop.model.Apparel;

public class Cart {
    List<Apparel> apparels;

}
