package com.reyansh.shop.model;

public enum Type {
    DISCOUNTED, NEW, NONE;
}
