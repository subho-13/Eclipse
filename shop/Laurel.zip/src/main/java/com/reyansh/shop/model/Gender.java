package com.reyansh.shop.model;

public enum Gender {
    MALE, FEMALE;
}
