package com.reyansh.shop.controller.signup;

public class SignupResponse {
    public boolean success;

    public boolean isSuccess() {
        return this.success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
